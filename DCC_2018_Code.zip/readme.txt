% Demo for paper "Automatic Salient Object Detection for Panoramic Images Using Region Growing and Fixation Prediction Model" 
% by Chubiao Zhu, Kan Huang,Ge Li
% To appear in Proceedings of IEEE Data Compression Conference, 2018.

1. put image into test file.
2. run demo.m.
3. get results in saliencymap file.