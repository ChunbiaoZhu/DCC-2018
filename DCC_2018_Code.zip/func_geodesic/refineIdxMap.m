function [Lablel_New,Spnum_New,PixelList] = refineIdxMap(Lablel_Old)
    
    [row,col] = size(Lablel_Old);
    Lablel_New = zeros(row,col);
    

    Spnum_Old = max(Lablel_Old(:))+1;   
    A_idx = zeros(Spnum_Old,1); 
    for i = 1:Spnum_Old
        idx0 = find(Lablel_Old==i-1);
        if ~isempty(idx0)
            A_idx(i) = 1;
        else
            A_idx(i) = 10000;
        end
    end
    idx1 = find(A_idx~=10000); 
    nm = length(idx1);
    idx2 = (1:nm)';
    for i = 1:nm
        idx0 = find(Lablel_Old==idx1(i)-1);
        Lablel_New(idx0) = idx2(i);
    end
    Spnum_New = max(Lablel_New(:)); % the actual superpixel number
    
    %
    PixelList = cell(Spnum_New,1);
    for i = 1:Spnum_New
        PixelList{i} = find(Lablel_New==i); 
    end