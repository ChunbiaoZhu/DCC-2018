function [meanRgbCol, pixelList, spNum, bdIds, Wgeo] = SLIC_Split(noFrameImg, spnumber_input)
% function [idxImg, adjcMatrix, pixelList, colDistM, meanPos, fgProb, Wgeo, fgProbMap, spColorMap] = SLIC_Split(noFrameImg, spnumber_input)

%% Segment using SLIC:
[h, w  chn] = size(noFrameImg);
compactness = 20; %the larger, the more regular patches will get
[idxImg, spNum] = SLIC_mex(noFrameImg, spnumber_input, compactness);

%%
adjcMatrix = GetAdjMatrix(idxImg, spNum);

%%
pixelList = cell(spNum, 1);
for n = 1:spNum
    pixelList{n} = find(idxImg == n);
end

%%
spNum = size(adjcMatrix, 1);
bdIds = GetBndPatchIds(idxImg);

%%
meanRgbCol = GetMeanColor(noFrameImg, pixelList); 
meanLabCol = colorspace('Lab<-', double(meanRgbCol)/255);
colDistM = GetDistanceMatrix(meanLabCol);

%%
[clipVal, geoSigma] = EstimateDynamicParas(adjcMatrix, colDistM);
Wgeo = GetGeoWeight(adjcMatrix, colDistM, bdIds, clipVal, geoSigma, true);

