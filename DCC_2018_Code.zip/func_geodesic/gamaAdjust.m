function out = gamaAdjust(in)

idx = find(in<0.2);
xx = in(idx);
in(idx) = 0;
in = imadjust(in, [0; 1], [0; 1], 0.7);  
in(idx) = xx;   
in = fastguidedfilter(in, in, 8, 0.15^2, 4);
in = normalization(in);
in(in<0.05)=0;
out = in;