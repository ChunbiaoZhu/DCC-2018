function weightMap = generWeight(m,n)
weightMap = cell(6,1);
a = 1:m;
b = 1:n;
[A,B] = meshgrid(a,b);
A = A';
B = B';

A1 = [1,1];
B1 = [1,n];
sigma = 128;
arg = -(abs(A-A1(1)) + abs(B-A1(2))+abs(A-B1(1)) + abs(B-B1(2)))/(3*sigma);
weightMap{1} = exp(arg);

A1 = [m,1];
B1 = [m,n];
sigma = 128;
arg = -(abs(A-A1(1)) + abs(B-A1(2))+abs(A-B1(1)) + abs(B-B1(2)))/(3*sigma);
weightMap{2} = exp(arg);

A1 = [1,1];
B1 = [m,1];
sigma = 128;
arg = -(abs(A-A1(1)) + abs(B-A1(2))+abs(A-B1(1)) + abs(B-B1(2)))/(3*sigma);
weightMap{3} = exp(arg);

A1 = [1,n];
B1 = [m,n];
sigma = 128;
arg = -(abs(A-A1(1)) + abs(B-A1(2))+abs(A-B1(1)) + abs(B-B1(2)))/(3*sigma);
weightMap{4} = exp(arg);

sigma = 128;
arg = -((A-ceil(m/2)).*(A-ceil(m/2)) + (B-ceil(n/2)).*(B-ceil(n/2)))/(2*sigma*sigma);
weightMap{5} = exp(arg);
weightMap{6} = weightMap{5};


