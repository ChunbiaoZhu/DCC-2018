function localMap = generLocalMap( SpMap )
%UNTITLED13 Summary of this function goes here
%   Detailed explanation goes here
SpMap = normalization(SpMap);
[m,n] = size(SpMap);


A = ones(127,127);
Cent_map = CenterBias(A, 40);
Cent_map = imresize(Cent_map, [m,n]);


Threshod = [0.2, 0.4, 0.6, 0.8];
k = length(Threshod);    
a = 1:m;
b = 1:n;
[A, B] = meshgrid(a, b);
A = A';
B = B';
sigma = 150;
Loca_map1 = zeros(m,n);

for i = 1:k
    BW_map = im2bw(SpMap, Threshod(i));
    idx = find(BW_map==1);
    num = size(idx, 1);
    [Idx_x,Idx_y] = ind2sub([m n],idx);
    Idx_x_Center = sum(Idx_x)/num;
    Idx_y_Center = sum(Idx_y)/num;
    arg = -( (A-Idx_x_Center).*(A-Idx_x_Center) + (B-Idx_y_Center).*(B-Idx_y_Center))/(2*sigma*sigma);
    h=exp(arg);
    Loca_map1=Loca_map1+h;
end

% Loca_map1=0.6*Loca_map1/4+0.4*Cent_map;
Loca_map1 = normalization(Loca_map1);
localMap = Loca_map1;

end

