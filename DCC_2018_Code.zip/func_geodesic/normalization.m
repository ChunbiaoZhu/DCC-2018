function output = normalization(input)
mi = min(input(:));
mx = max(input(:));
output = (input-mi)./(mx-mi+eps);

