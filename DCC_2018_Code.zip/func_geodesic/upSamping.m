function Out = upSamping(spProb, bdIds, spNum, Wgeo) 
step = 3;      
D_sam = repmat(sum(Wgeo,2), 1, spNum);
Wgeo_normal = Wgeo./(D_sam+eps);  

for loop = 1:step       
    most_sal_sup = find(spProb > 0.93);
    if numel(most_sal_sup) < 0.05*spNum
        sal_diff = setdiff(1:spNum, most_sal_sup);
        spProb(sal_diff) = normalization(spProb(sal_diff));
    end       
    spProb = Wgeo_normal*spProb;
    spProb = normalization(spProb);
    
    SpBond = spProb(bdIds);
    idx1 = find(SpBond<0.2);
    idx = bdIds(idx1);
    spProb(idx) = 0; 
end 
    Out = spProb;
end

