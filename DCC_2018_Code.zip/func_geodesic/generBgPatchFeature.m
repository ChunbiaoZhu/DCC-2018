function bgPatchFeature = generBgPatchFeature(imgRgb, imgLab, imgIRgBy, bgPatchInd, patchSize, m, n)
if max(m,n)<200
%     im6_RGB = im2col_general(imgRgb, [patchSize patchSize]);% collect all the patches of the ith image in a matrix 
    im6_LAB = im2col_general(imgLab, [patchSize patchSize]);% collect all the patches of the ith image in a matrix   
    im6_IRgBy = im2col_general(imgIRgBy, [patchSize patchSize]);% collect all the patches of the ith image in a matrix
else
%     im6_RGB = im2colstep(imgRgb, [patchSize patchSize 3],[2 2 1]);
    im6_LAB = im2colstep(imgLab, [patchSize patchSize 3],[2 2 1]);
    im6_IRgBy = im2colstep(imgIRgBy, [patchSize patchSize 3],[2 2 1]);
end


% [x1,y1] = size(im6_LAB);
% [x2,y2] = size(im6_RGB);
% im6 = zeros(x1+x2,y1);
% im6(1:x1,:) = im6_LAB;
% im6(x1+1:x1+x2,:) = im6_RGB;


[x1,y1] = size(im6_LAB);
[x2,y2] = size(im6_IRgBy);
im6 = zeros(x1+x2,y1);
im6(1:x1,:) = im6_LAB;
im6(x1+1:x1+x2,:) = im6_IRgBy;


% im6 = im6_RGB;
% 

% [sparseCof, allfeats] = calsparseCof(im6_RGB, im6_LAB, im6_IRgBy, patchSize, bgPatchInd);
% nn = size(sparseCof,1);
% mm = size(allfeats,1);
% im6(1:nn,:) = sparseCof;
% im6(nn+1:nn+mm,:) = allfeats;


%%
bgPatchFeature = cell(6,1);
bgPatchFeature{6} = im6;    
bgPatchFeature{1} = im6(:, bgPatchInd{1});
bgPatchFeature{2} = im6(:, bgPatchInd{2});
bgPatchFeature{3} = im6(:, bgPatchInd{3});
bgPatchFeature{4} = im6(:, bgPatchInd{4});
bgPatchFeature{5} = im6(:, bgPatchInd{5});
