function BayesPosterior = calculateBayesPosterior(prior,input_imlab,r,c)
%% Calculate the Bayesian posterior probability.

BayesPosterior = zeros(r,c);
BW = im2bw(prior,1*mean(prior(:)));
ind = find(BW==1);
out_ind = find(BW==0);
 
smoothFactor = 10;
numBin = 50;
BayesPosterior=Bayes(prior, input_imlab, ind, out_ind, numBin, smoothFactor, r, c);
BayesPosterior = normalization(BayesPosterior);

