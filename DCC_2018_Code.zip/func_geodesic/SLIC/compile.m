function compile
mex SLIC_mex.cpp SLIC.cpp