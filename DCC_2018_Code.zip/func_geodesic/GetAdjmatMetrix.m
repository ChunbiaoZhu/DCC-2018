function  Adjmat = GetAdjmatMetrix (Superpixels,Spnum)
row=size(Superpixels,1);
Adjmat = eye([Spnum Spnum]);

dx = Superpixels ~= Superpixels(:,[2:end end]); 
dy = Superpixels ~= Superpixels([2:end end], :);

ind1 = find(dy); 
ind2 = ind1 + 1; 
s1 = Superpixels(ind1);
s2 = Superpixels(ind2);

Adjmat(sub2ind([Spnum, Spnum], s1, s2)) = 1;
Adjmat(sub2ind([Spnum, Spnum], s2, s1)) = 1;

ind3 = find(dx);
ind4 = ind3 + row;
s3 = Superpixels(ind3);
s4 = Superpixels(ind4);

Adjmat(sub2ind([Spnum, Spnum], s3, s4)) = 1;
Adjmat(sub2ind([Spnum, Spnum], s4, s3)) = 1;