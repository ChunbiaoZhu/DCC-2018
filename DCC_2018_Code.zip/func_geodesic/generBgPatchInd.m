function bgPatchInd = generBgPatchInd(m,n,BW)
if max(m,n)>200 
   m=ceil(m/2);
   n=ceil(n/2);
end

bgPatchInd = cell(6,1);    
L_idx = 1:m*n;
L_idx = L_idx';
[x,y] = ind2sub([m,n],L_idx);
tt(:,1) = x;
tt(:,2) = y;
ttt = sortrows(tt,1);
       
max_x = max(find(ttt(:,1)==BW)); 
min_x = min(find(ttt(:,1)==m-BW+1));
    
BgIdx{1} = ttt(1:max_x,:); %��
BgIdx{1} = sub2ind([m,n],BgIdx{1}(:,1),BgIdx{1}(:,2));
BgIdx{2} = ttt(min_x:m*n,:);%��
BgIdx{2} = sub2ind([m,n],BgIdx{2}(:,1),BgIdx{2}(:,2));
BgIdx{3} = L_idx(1:BW*n);%��
BgIdx{4} = L_idx(m*n-BW*n+1:m*n); %��        
BgIdx{5} = [BgIdx{1};BgIdx{2};BgIdx{3};BgIdx{4}];
BgIdx{5} = unique(BgIdx{5});
BgIdx{6} = L_idx;
    
bgPatchInd{1}=[BgIdx{1};BgIdx{3}];
bgPatchInd{2}=[BgIdx{1};BgIdx{4}];
bgPatchInd{3}=[BgIdx{2};BgIdx{3}];
bgPatchInd{4}=[BgIdx{2};BgIdx{4}];
bgPatchInd{5}=BgIdx{5};
bgPatchInd{6}=BgIdx{6};
    