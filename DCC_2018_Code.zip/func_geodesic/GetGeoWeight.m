function Wgeo = GetGeoWeight(adjcMatrix, weightMatrix, bdIds, clipVal, geo_sigma, link_boundary)

% Compute the weights of geodestic distance for all superpixels
% Note that the function is not original,
% it comes from the code "Saliency Optimization from Robust Background Detection, CVPR2014"


if (nargin < 6)
    link_boundary = true;    
end
if (link_boundary)
    adjcMatrix = LinkBoundarySPs(adjcMatrix, bdIds);
end

adjcMatrix = tril(adjcMatrix, -1);
edgeWeight = weightMatrix(adjcMatrix > 0);
edgeWeight = max(0, edgeWeight - clipVal);


% Cal pair-wise shortest path cost (geodesic distance)
geoDistMatrix = graphallshortestpaths(sparse(adjcMatrix), 'directed', false, 'Weights', edgeWeight);

Wgeo = Dist2WeightMatrix(geoDistMatrix, geo_sigma);