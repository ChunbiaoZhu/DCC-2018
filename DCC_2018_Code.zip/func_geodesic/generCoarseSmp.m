function [spMap, spCoarse] = generCoarseSmp(noFrameImg, pixelList, spNum, bdIds, Wgeo)
% res: resolution
% BW: wideth of image border 

patchSize = [7, 7, 7];
res = [250, 160, 100];
BW = [15, 10, 5];

spMap1 = oneScaleSalMap(noFrameImg, res(1), BW(1), patchSize(1));
spMap2 = oneScaleSalMap(noFrameImg, res(2), BW(2), patchSize(2));
spMap3 = oneScaleSalMap(noFrameImg, res(3), BW(3), patchSize(3));
spMap = (spMap1+spMap2+spMap3)/3;


% Location prior
% This step is optional, it could help suppress noises far away from the
% main targets for some images.
locationRefineFlag = true; 
if locationRefineFlag
    localMap = generLocalMap(spMap);
    spCoarse = spMap.*localMap;
    spCoarse = normalization(spCoarse);
    spCoarse(spCoarse<0.05) = 0;
else
    spCoarse = spMap;
    spCoarse = normalization(spCoarse);
    spCoarse(spCoarse<0.05) = 0;
end

% This is the up-sampling method based on the geodesic distances of superpixels
% described in section II-C in our paper.
% We find that it is used to smooth the coarse saliency map before Bayesian
% perspective could slightly improve the final performance.
upsamplingFlag = true;
if upsamplingFlag
    spCoarseProb = generProb(spCoarse, pixelList, spNum); 
    spCoarseProb = upSamping(spCoarseProb, bdIds, spNum, Wgeo);
    spCoarse = generMaps(noFrameImg, spCoarseProb, pixelList);
end
    
