function distM = GetDistanceMatrix(feature,lamda)
% Get pair-wise distance matrix between each rows in feature
% Each row of feature correspond to a sample

spNum = size(feature, 1);
DistM2 = zeros(spNum, spNum);
lamda=[1,1,1,1,1,1];


for n = 1:size(feature, 2)
    DistM2 = DistM2 + lamda(n)*( repmat(feature(:,n), [1, spNum]) - repmat(feature(:,n)', [spNum, 1]) ).^2;
end
distM = sqrt(DistM2);