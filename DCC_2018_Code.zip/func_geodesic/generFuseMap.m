function fuseMap = generFuseMap(entropVal, MahaDistMap, m, n, numBdy, patchSize)

[m1,n1] = size(MahaDistMap{1});

row = m - 1 + patchSize; 
col = n - 1 + patchSize;
mag = (patchSize-1)/2;
    
Arry = entropVal(1:numBdy,1);
T = mean(Arry);
idx = find(Arry<=T);
numFuseMap = size(idx,1);
fuseInitMap = zeros(m1,n1);


for i=1:numFuseMap
    fuseInitMap = fuseInitMap + MahaDistMap{idx(i)};
end
fuseInitMap = fuseInitMap/numFuseMap;
fuseInitMap = normalization(fuseInitMap);
fuseInitMap(fuseInitMap<0.05) = 0;

fuseInitMap = bordercut(fuseInitMap,0.01);
fuseInitMap = imresize(fuseInitMap,[m,n]);

fuseMap = zeros(row,col);
fuseMap(mag+1:row-mag,mag+1:col-mag) = fuseInitMap;
