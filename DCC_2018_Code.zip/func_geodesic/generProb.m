function spProb = generProb(grayMap, pixelList, spNum)
%UNTITLED14 Summary of this function goes here
%   Detailed explanation goes here
    spProb = zeros(spNum,1);
    for i=1:spNum
        spProb(i) = mean(grayMap(pixelList{i}));
    end
end

