function oneScaleSpMap = oneScaleSalMap(In, res, BW, patchSize)

if max(In(:))>1
    In = im2double(In);
end
[row,col,dim] = size(In);
im = imresize(In,res/max(row,col));
im = imfilter(im, fspecial('gaussian',7,3));

[row1,col1,k1] = size(im);
m = row1-patchSize+1;
n = col1-patchSize+1;

[imgRgb,imgLab,imgIRgBy] = normalizeColor(im, 1); % Color information
bgPatchInd = generBgPatchInd(m, n, BW); % 
bgPatchFeature = generBgPatchFeature(imgRgb, imgLab, imgIRgBy, bgPatchInd, patchSize, m, n); %  

%% Generating the spaces of background-based distribution
% numBdy = 5  
numBdy = 4; 
eigenVector = generSBD(bgPatchFeature, numBdy);
allPatchFeature=bgPatchFeature{6};
allPatchFeature=bsxfun(@minus, allPatchFeature, mean(allPatchFeature, 2));

cof = cell(numBdy,1);
for i = 1:numBdy
    cof{i} = eigenVector{i}'*allPatchFeature;
end

%% Calculate Mahalanobis distance
[MahaDistMap, entropVal] = calMahaDist(cof, bgPatchInd, m, n, res, numBdy);


%% Entropy based fusion
oneScaleSpMap = generFuseMap(entropVal, MahaDistMap, m, n, numBdy, patchSize);

oneScaleSpMap = imresize(oneScaleSpMap,[row,col]);
oneScaleSpMap(oneScaleSpMap<0.05) = 0;

