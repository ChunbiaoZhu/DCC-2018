function Smp = Rectify(in,frameRecord)
    h = frameRecord(1);
    w = frameRecord(2);
    top = frameRecord(3);
    bot = frameRecord(4);
    left = frameRecord(5);
    right = frameRecord(6);

    partialH = bot - top + 1;
    partialW = right - left + 1;
    
    if partialH ~= h || partialW ~= w
        Smp = ones(h, w) * 0;
        Smp(top:bot, left:right) = in;
    else
        Smp = in;
    end