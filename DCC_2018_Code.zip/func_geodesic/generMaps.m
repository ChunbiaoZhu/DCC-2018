function Map = generMaps(In, Prob, pixelList)
[h, w, chn] = size(In);
[spNum, dim] = size(Prob);

if dim == 1 % gray image
    Map = zeros(h, w);    
    for i = 1:spNum
        Map(pixelList{i}) = Prob(i);
    end
else    
    Map = zeros(h*w, chn); % color image
    for i = 1:spNum
        x = size(pixelList{i}, 1);
        Map(pixelList{i},:) = ones(x,1)*(Prob(i,:)/255);
    end
    Map=reshape(Map, h, w, chn);
end
Map = normalization(Map);
Map(Map<0.05) = 0;