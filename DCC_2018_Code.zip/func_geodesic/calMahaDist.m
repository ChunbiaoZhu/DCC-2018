function [MahaDistMap, entropVal] = calMahaDist(cof, bgPatchInd, m, n, res, numBdy)
if max(m,n)>200
    m=ceil(m/2);
    n=ceil(n/2);
end
MahaDistMap = cell(numBdy, 1);
entropVal = zeros(numBdy, 1);
totelNum = size(bgPatchInd{6}, 1);
weightMap = generWeight(m,n);

for i = 1 : numBdy

    cof1 = cof{i};
    cofBd = cof1(:,bgPatchInd{i});
    meanCofBd = mean(cofBd,2);
    cv = cov(cofBd'); %Э�������    
    cvInvMat = inv(cv);
    cvInvMat = sqrtm(cvInvMat);        
    dist1 = cof1 - repmat(meanCofBd,[1,totelNum]);
    t = cvInvMat*dist1;
    

    
    % l2 norm
    t = t.^2;
    t = sum(t);
    dist = sqrt(t); 
    

    initMap = reshape(dist,m,n);
    initMap(initMap<0.001)=0;    
    initMap=normalization(initMap);
    
    initMap = imfilter(initMap, fspecial('gaussian',5,1));    
    if res<128
        se = strel('disk',1);
    else
        se = strel('disk',2);
    end   
    initMap = imerode(initMap,se);
    initMap(initMap<0.05)=0;
         
    T = mean(initMap(:));
    if T<0.06
        initMap = initMap - 0.5*T;
    else
        initMap = initMap - T;
    end
    initMap(initMap<0)=0;

    initMap = weightMap{i}.* initMap;
    initMap = initMap / max(initMap(:));
    
    entropVal(i) = entropy1(initMap,res);
    MahaDistMap{i} = initMap;
end