function [ bdIds, Wgeo] = generSuperpixels(noFrameImg)
% Two methods for choice : SLIC or LSC (cvpr2015) 

useSLIC = true; 
if useSLIC % SLIC superpixles 
%     spnumber = 350;
    [meanRgbCol,  bdIds, Wgeo] = SLIC_Split(noFrameImg, spnumber);    
%     spColorMap = generMaps(noFrameImg, meanRgbCol, pixelList); 

else  % LSC superpixles      
    rc = 0.075;
    spnumber = 275;
    [meanRgbCol, pixelList, spNum, bdIds, Wgeo] = SLC_Split(noFrameImg, spnumber, rc);
%     spColorMap = generMaps(noFrameImg, meanRgbCol, pixelList);
end