function [imgRgb,imgLab,imgIRgBy] = normalizeColor(In, isNormilize)

if max(In(:))>1
    In = im2double(In);
end

%
cform = makecform('srgb2lab');
lab = applycform(In,cform);
ImgL = lab(:,:,1);
ImgA = lab(:,:,2);
ImgB = lab(:,:,3);
if isNormilize == 1
    ImgL = normalization(ImgL);
    ImgA = normalization(ImgA);
    ImgB = normalization(ImgB);
end
imgLab(:,:,1) = ImgL;
imgLab(:,:,2) = ImgA;
imgLab(:,:,3) = ImgB; 

%
r = In(:,:,1);b = In(:,:,2);g = In(:,:,3);
I = (r+b+g)/3;
RG = r-g;
BY = b-(r+g)/2;

if isNormilize == 1
    I = normalization(I);
    RG = normalization(RG);
    BY = normalization(BY);
end
    
imgIRgBy(:,:,1) = I;
imgIRgBy(:,:,2) = RG;
imgIRgBy(:,:,3) = BY; 
%

imgRgb=In;

