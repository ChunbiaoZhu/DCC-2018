function [meanRgbCol, pixelList, spNum, bdIds, Wgeo] = SLC_Split(noFrameImg, spnumber, rc)
    [h, w, chn] = size(noFrameImg);
    idxImgOld = LSC_mex(noFrameImg,spnumber,rc);
    [idxImg, spNum, pixelList] = refineIdxMap(idxImgOld);

    adjcMatrix = GetAdjmatMetrix(idxImg, spNum);
%     adjcMatrix = GetAdjMatrix(idxImg, spNum);
    bdIds = GetBndPatchIds(idxImg);

    meanRgbCol = GetMeanColor(noFrameImg, pixelList); 
    meanLabCol = colorspace('Lab<-', double(meanRgbCol)/255);
    meanPos = GetNormedMeanPos(pixelList, h, w);
    colDistM = GetDistanceMatrix(meanLabCol);
    
    [clipVal, geoSigma] = EstimateDynamicParas(adjcMatrix, colDistM);
    Wgeo = GetGeoWeight(adjcMatrix, colDistM, bdIds, clipVal, geoSigma, true);
