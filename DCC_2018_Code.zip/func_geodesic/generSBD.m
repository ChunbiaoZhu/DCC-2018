function eigenVector = generSBD(bgPatchFeature, numBdy)
tk = 0.99995;
eigenVector = cell(numBdy,1);
for i=1:numBdy
    bgPatchFeature{i} = bsxfun(@minus, bgPatchFeature{i}, mean(bgPatchFeature{i},2)); % patch-mean removal 
    Rx = bgPatchFeature{i}*bgPatchFeature{i}'; % input images' covariance matrix
    [E,D] = eig(Rx);
    [trash ,ind] = sort(diag(D),'descend');
    xx=cumsum(trash)/sum(trash);
    xxx=length(find(xx<=tk));
    eigenVector{i} = E(:,ind(1:xxx));  % principal eigenvectors
end