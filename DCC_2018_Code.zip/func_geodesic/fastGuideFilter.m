function Out = fastGuideFilter(In)
if max(In(:)) > 1
    In = im2double(In);
end

r = 8;
eps = 0.15^2;

Out = zeros(size(In));
s = 4;
p = In;
Out(:, :, 1) = fastguidedfilter(In(:, :, 1), p(:, :, 1), r, eps, s);
Out(:, :, 2) = fastguidedfilter(In(:, :, 2), p(:, :, 2), r, eps, s);
Out(:, :, 3) = fastguidedfilter(In(:, :, 3), p(:, :, 3), r, eps, s);
